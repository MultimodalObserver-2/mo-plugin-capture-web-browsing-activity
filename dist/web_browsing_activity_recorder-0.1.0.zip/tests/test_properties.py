import sys
import os
import types
import unittest
import importlib.util

SRC = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src',
                                    'web_browsing_activity_recorder'))


class MockProperties:
    def __init__(self):
        self.fields = {}
        self.defaults = {}

    def add_text(self, key, label=None):
        self.fields[key] = {'type': 'text', 'label': label}

    def add_int(self, key, label=None, min=None, max=None, step=None):
        self.fields[key] = {'type': 'int', 'label': label, 'min': min, 'max': max, 'step': step}

    def add_bool(self, key, label=None):
        self.fields[key] = {'type': 'bool', 'label': label}

    def set_default(self, key, value):
        self.defaults[key] = value


def load_properties():
    try:
        mo = importlib.import_module('mo')
    except ImportError:
        mo = types.ModuleType('mo')
        sys.modules['mo'] = mo
    if not hasattr(mo, 'translate'):
        mo.translate = lambda s: s

    real_mo_core = sys.modules.get('mo.core')
    mo_core = types.ModuleType('_wb_props_mo_core')
    mo_core.Properties = MockProperties
    sys.modules['mo.core'] = mo_core
    try:
        spec = importlib.util.spec_from_file_location(
            '_wb_props_mod', os.path.join(SRC, 'properties.py'))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
    finally:
        if real_mo_core is not None:
            sys.modules['mo.core'] = real_mo_core
        else:
            sys.modules.pop('mo.core', None)
    return mod


props_mod = load_properties()


class TestWebBrowsingProperties(unittest.TestCase):

    def test_properties_object_exists(self):
        self.assertIsInstance(props_mod.properties, MockProperties)

    def test_server_host_field_exists(self):
        self.assertIn('server_host', props_mod.properties.fields)

    def test_server_host_text(self):
        self.assertEqual(props_mod.properties.fields['server_host']['type'], 'text')

    def test_server_host_default(self):
        self.assertEqual(props_mod.properties.defaults['server_host'], 'localhost')

    def test_server_port_field_exists(self):
        self.assertIn('server_port', props_mod.properties.fields)

    def test_server_port_int(self):
        self.assertEqual(props_mod.properties.fields['server_port']['type'], 'int')

    def test_server_port_default(self):
        self.assertEqual(props_mod.properties.defaults['server_port'], 3000)

    def test_export_csv_field_exists(self):
        self.assertIn('export_to_csv', props_mod.properties.fields)

    def test_export_csv_default_false(self):
        self.assertEqual(props_mod.properties.defaults['export_to_csv'], False)

    def test_stream_clients_field_exists(self):
        self.assertIn('stream_to_clients', props_mod.properties.fields)

    def test_stream_clients_default_true(self):
        self.assertEqual(props_mod.properties.defaults['stream_to_clients'], True)

    def test_four_fields_total(self):
        self.assertEqual(len(props_mod.properties.fields), 4)


if __name__ == '__main__':
    unittest.main()
