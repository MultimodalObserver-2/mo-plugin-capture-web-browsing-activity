import json
import os
import socket
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from unittest.mock import MagicMock, patch

from mo.modules.capture import CaptureData
from web_browsing_activity_recorder.main import WebBrowsingActivityCapturePlugin
from web_browsing_activity_recorder.models import (
    CSV_HEADERS,
    Keystroke,
    MouseClick,
    MouseMove,
    MouseUp,
    SearchAction,
    TabAction,
    parse_event,
)
from web_browsing_activity_recorder.server import MOUNTED, PAUSED, RUNNING, WebActivityHTTPServer


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("localhost", 0))
        return s.getsockname()[1]


def get_response(url: str) -> tuple[int, dict]:
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, {}


def post_request(url: str, body: dict | None = None) -> tuple[int, str]:
    data = json.dumps(body or {}).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=3) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def make_plugin(settings_map: dict | None = None) -> WebBrowsingActivityCapturePlugin:
    plugin = WebBrowsingActivityCapturePlugin()
    plugin.settings = MagicMock()
    plugin.settings.get_setting.side_effect = lambda k: (settings_map or {}).get(k)
    plugin.load()
    return plugin


class TestParseEvent(unittest.TestCase):

    TS = 123.45

    def test_keystrokes(self):
        ev = parse_event("/keystrokes", {"browser": "Chrome", "pageUrl": "https://x.com",
                                         "pageTitle": "X", "keyValue": "a"}, self.TS)
        self.assertIsNotNone(ev)
        self.assertEqual(ev["event_type"], "keystrokes")
        self.assertEqual(ev["browser"], "Chrome")
        self.assertEqual(ev["keyValue"], "a")
        self.assertEqual(ev["captureTimestamp"], self.TS)

    def test_mouse_clicks(self):
        ev = parse_event("/mouseClicks", {"browser": "Firefox", "pageUrl": "u",
                                          "xPage": 10, "yPage": 20, "button": 1}, self.TS)
        self.assertEqual(ev["event_type"], "mouseClicks")
        self.assertEqual(ev["xPage"], 10)
        self.assertEqual(ev["button"], 1)

    def test_mouse_moves(self):
        ev = parse_event("/mouseMoves", {"xMovement": 3, "yMovement": -2}, self.TS)
        self.assertEqual(ev["event_type"], "mouseMoves")
        self.assertEqual(ev["xMovement"], 3)
        self.assertEqual(ev["yMovement"], -2)

    def test_mouse_ups(self):
        ev = parse_event("/mouseUps", {"selectedText": "hello"}, self.TS)
        self.assertEqual(ev["event_type"], "mouseUps")
        self.assertEqual(ev["selectedText"], "hello")

    def test_searchs(self):
        ev = parse_event("/searchs", {"search": "pytest"}, self.TS)
        self.assertEqual(ev["event_type"], "searchs")
        self.assertEqual(ev["search"], "pytest")

    def test_tabs(self):
        ev = parse_event("/tabs", {"tabUrl": "https://x.com", "actionType": "open",
                                   "tabIndex": 0, "tabId": 1, "windowId": 2}, self.TS)
        self.assertEqual(ev["event_type"], "tabs")
        self.assertEqual(ev["actionType"], "open")
        self.assertEqual(ev["tabId"], 1)

    def test_unknown_path_returns_none(self):
        self.assertIsNone(parse_event("/unknown", {}, self.TS))

    def test_missing_fields_use_empty_defaults(self):
        ev = parse_event("/keystrokes", {}, self.TS)
        self.assertEqual(ev["browser"], "")
        self.assertEqual(ev["keyValue"], "")


class TestModels(unittest.TestCase):

    def test_keystroke_to_dict_has_event_type(self):
        d = Keystroke(browser="B", keyValue="x").to_dict()
        self.assertEqual(d["event_type"], "keystrokes")
        self.assertNotIn("event_type", Keystroke.__dataclass_fields__)

    def test_mouse_up_csv_row_quotes_comma(self):
        mu = MouseUp(selectedText="hello, world")
        row = mu.to_csv_row()
        self.assertIn('"hello, world"', row)

    def test_csv_headers_all_event_types(self):
        expected_types = {"keystrokes", "mouseClicks", "mouseMoves", "mouseUps", "searchs", "tabs"}
        self.assertEqual(set(CSV_HEADERS.keys()), expected_types)

    def test_tab_action_to_dict(self):
        d = TabAction(tabUrl="https://x.com", actionType="close").to_dict()
        self.assertEqual(d["event_type"], "tabs")
        self.assertEqual(d["tabUrl"], "https://x.com")

    def test_search_action_csv_row(self):
        row = SearchAction(browser="B", search="Python").to_csv_row()
        self.assertIn("Python", row)


class TestWebActivityHTTPServer(unittest.TestCase):

    def setUp(self):
        self.port = free_port()
        self.received: list[CaptureData] = []
        self.server = WebActivityHTTPServer(
            host="localhost",
            port=self.port,
            get_timestamp=lambda: 1.0,
            on_data=self.received.append,
        )
        self.server.start()
        time.sleep(0.1)

    def tearDown(self):
        self.server.stop()
        time.sleep(0.1)

    def base(self):
        return f"http://localhost:{self.port}"

    def test_address_property(self):
        self.assertEqual(self.server.address, f"http://localhost:{self.port}")

    def test_initial_state_is_mounted(self):
        self.assertEqual(self.server.state, MOUNTED)

    def test_get_status_before_start(self):
        code, body = get_response(f"{self.base()}/status")
        self.assertEqual(code, 200)
        self.assertEqual(body["status"], MOUNTED)

    def test_post_start_sets_running(self):
        code, _ = post_request(f"{self.base()}/start")
        self.assertEqual(code, 200)
        self.assertEqual(self.server.state, RUNNING)

    def test_post_stop_sets_mounted(self):
        post_request(f"{self.base()}/start")
        code, _ = post_request(f"{self.base()}/stop")
        self.assertEqual(code, 200)
        self.assertEqual(self.server.state, MOUNTED)

    def test_event_before_start_returns_503(self):
        code, _ = post_request(f"{self.base()}/keystrokes", {"keyValue": "a"})
        self.assertEqual(code, 503)
        self.assertEqual(len(self.received), 0)

    def test_event_after_start_calls_on_data(self):
        post_request(f"{self.base()}/start")
        code, _ = post_request(f"{self.base()}/keystrokes",
                        {"browser": "B", "pageUrl": "u", "keyValue": "z"})
        self.assertEqual(code, 200)
        self.assertEqual(len(self.received), 1)
        self.assertEqual(self.received[0].data["keyValue"], "z")

    def test_unknown_path_returns_200_but_no_data(self):
        post_request(f"{self.base()}/start")
        code, _ = post_request(f"{self.base()}/notAnEvent", {})
        self.assertEqual(code, 200)
        self.assertEqual(len(self.received), 0)

    def test_pause_drops_events(self):
        post_request(f"{self.base()}/start")
        self.server.pause()
        code, _ = post_request(f"{self.base()}/keystrokes", {"keyValue": "x"})
        self.assertEqual(code, 503)
        self.assertEqual(len(self.received), 0)

    def test_resume_accepts_events_again(self):
        post_request(f"{self.base()}/start")
        self.server.pause()
        self.server.resume()
        code, _ = post_request(f"{self.base()}/keystrokes", {"keyValue": "y"})
        self.assertEqual(code, 200)
        self.assertEqual(len(self.received), 1)

    def test_all_event_paths_accepted(self):
        post_request(f"{self.base()}/start")
        paths = [
            ("/keystrokes", {"keyValue": "k"}),
            ("/mouseClicks", {"xPage": 1, "yPage": 2}),
            ("/mouseMoves", {"xMovement": 1, "yMovement": 0}),
            ("/mouseUps", {"selectedText": "hi"}),
            ("/searchs", {"search": "q"}),
            ("/tabs", {"tabUrl": "u", "actionType": "open"}),
        ]
        for path, body in paths:
            code, _ = post_request(f"{self.base()}{path}", body)
            self.assertEqual(code, 200, f"Falló {path}")
        self.assertEqual(len(self.received), len(paths))


class TestWebBrowsingActivityPlugin(unittest.TestCase):

    def setUp(self):
        self.port = free_port()
        settings = {"server_host": "localhost", "server_port": self.port,
                    "export_to_csv": False, "stream_to_clients": False}
        self.plugin = make_plugin(settings)
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        self.plugin.unload()
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def base(self):
        return f"http://localhost:{self.port}"

    def test_load_initial_state(self):
        self.assertIsNone(self.plugin._http_server)
        self.assertIsNone(self.plugin._session_path)
        self.assertEqual(self.plugin._output_files, {})

    def test_prepare_creates_output_dir(self):
        self.plugin.prepare(self.tmp, "sess")
        out_dir = os.path.join(self.tmp, "sess")
        self.assertTrue(os.path.isdir(out_dir))

    def test_start_launches_http_server(self):
        self.plugin.prepare(self.tmp, "sess")
        self.plugin.start(0.0, time.monotonic, lambda d: None)
        time.sleep(0.1)
        self.assertIsNotNone(self.plugin._http_server)
        code, _ = get_response(f"{self.base()}/status")
        self.assertEqual(code, 200)

    def test_stop_shuts_down_server(self):
        self.plugin.prepare(self.tmp, "sess")
        self.plugin.start(0.0, time.monotonic, lambda d: None)
        time.sleep(0.1)
        self.plugin.stop(1.0)
        time.sleep(0.2)
        self.assertIsNone(self.plugin._http_server)

    def test_pause_resume_propagated(self):
        self.plugin.prepare(self.tmp, "sess")
        received = []
        self.plugin.start(0.0, time.monotonic, received.append)
        time.sleep(0.1)
        post_request(f"{self.base()}/start")
        self.plugin.pause(0.5)
        code, _ = post_request(f"{self.base()}/keystrokes", {"keyValue": "x"})
        self.assertEqual(code, 503)
        self.plugin.resume(1.0)
        code, _ = post_request(f"{self.base()}/keystrokes", {"keyValue": "y"})
        self.assertEqual(code, 200)

    def test_get_file_extension(self):
        self.assertEqual(self.plugin.get_file_extension(), "json")

    def test_get_output_descriptor_without_server(self):
        desc = self.plugin.get_output_descriptor()
        self.assertIn("format", desc)
        self.assertEqual(desc["format"], "web_activity_map")
        self.assertIsNone(desc["server_address"])

    def test_get_output_descriptor_with_server(self):
        self.plugin.prepare(self.tmp, "sess")
        self.plugin.start(0.0, time.monotonic, lambda d: None)
        time.sleep(0.1)
        desc = self.plugin.get_output_descriptor()
        self.assertIn(str(self.port), desc["server_address"])
        self.plugin.stop(1.0)

    def test_unload_stops_server(self):
        self.plugin.prepare(self.tmp, "sess")
        self.plugin.start(0.0, time.monotonic, lambda d: None)
        time.sleep(0.1)
        self.plugin.unload()
        self.assertIsNone(self.plugin._http_server)


class TestWebBrowsingActivitySave(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.plugin = make_plugin({"stream_to_clients": False, "export_to_csv": False})
        self.plugin.prepare(self.tmp, "web_sess")
        self.out_dir = os.path.join(self.tmp, "web_sess")

    def tearDown(self):
        self.plugin.unload()
        import shutil
        shutil.rmtree(self.tmp, ignore_errors=True)

    def keystroke_data(self, ts: float = 1.0) -> CaptureData:
        ev = parse_event("/keystrokes", {"browser": "Chrome", "keyValue": "a"}, ts)
        return CaptureData(timestamp=ts, data=ev)

    def tab_data(self, ts: float = 2.0) -> CaptureData:
        ev = parse_event("/tabs", {"tabUrl": "https://x.com", "actionType": "open"}, ts)
        return CaptureData(timestamp=ts, data=ev)

    def test_save_creates_json_for_event_type(self):
        self.plugin.save([self.keystroke_data()], end_of_data=True)
        json_path = os.path.join(self.out_dir, "keystrokes.json")
        self.assertTrue(os.path.exists(json_path))
        with open(json_path, encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["keyValue"], "a")

    def test_save_multiple_event_types(self):
        items = [self.keystroke_data(1.0), self.tab_data(2.0)]
        self.plugin.save(items, end_of_data=True)
        self.assertTrue(os.path.exists(os.path.join(self.out_dir, "keystrokes.json")))
        self.assertTrue(os.path.exists(os.path.join(self.out_dir, "tabs.json")))

    def test_save_multiple_events_same_type(self):
        items = [self.keystroke_data(i) for i in range(4)]
        self.plugin.save(items, end_of_data=True)
        with open(os.path.join(self.out_dir, "keystrokes.json"), encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(len(data), 4)

    def test_save_with_csv(self):
        self.plugin.settings.get_setting.side_effect = lambda k: (
            True if k == "export_to_csv" else None
        )
        self.plugin.save([self.keystroke_data()], end_of_data=True)
        csv_path = os.path.join(self.out_dir, "keystrokes.csv")
        self.assertTrue(os.path.exists(csv_path))
        with open(csv_path, encoding="utf-8") as f:
            lines = f.readlines()
        self.assertGreaterEqual(len(lines), 2)
        self.assertIn("browser", lines[0])

    def test_save_ignores_non_dict(self):
        bad = CaptureData(timestamp=0.0, data="no soy un dict")
        self.plugin.save([bad], end_of_data=True)
        self.assertEqual(os.listdir(self.out_dir), [])

    def test_end_of_data_writes_map_file(self):
        self.plugin.save([self.keystroke_data()], end_of_data=True)
        map_path = os.path.join(self.tmp, "web_sess_web_activity_map.json")
        self.assertTrue(os.path.exists(map_path))
        with open(map_path, encoding="utf-8") as f:
            m = json.load(f)
        self.assertIn("keystrokes", m)

    def test_end_of_data_closes_files(self):
        self.plugin.save([self.keystroke_data()], end_of_data=True)
        self.assertEqual(self.plugin._output_files, {})

    def test_json_valid_after_end_of_data(self):
        items = [self.keystroke_data(float(i)) for i in range(5)]
        self.plugin.save(items, end_of_data=True)
        with open(os.path.join(self.out_dir, "keystrokes.json"), encoding="utf-8") as f:
            data = json.load(f)
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 5)

    def test_save_split_batches(self):
        for i in range(3):
            self.plugin.save([self.keystroke_data(float(i))])
        self.plugin.save([], end_of_data=True)
        with open(os.path.join(self.out_dir, "keystrokes.json"), encoding="utf-8") as f:
            data = json.load(f)
        self.assertEqual(len(data), 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
