import os
import sys
import types

_comm = types.ModuleType("mo.modules.communication")
_comm_svc = types.ModuleType("mo.modules.communication.services")
_comm_ss = types.ModuleType("mo.modules.communication.services.server_service")


class StubServerService:
    def __new__(cls, *args, **kwargs):
        return object.__new__(cls)

    def send_capture_data(self, data) -> None:
        pass

    async def add_active_capture_plugin(self, plugin_id, config=None) -> None:
        pass


_comm_ss.ServerService = StubServerService
sys.modules.setdefault("mo.modules.communication", _comm)
sys.modules.setdefault("mo.modules.communication.services", _comm_svc)
sys.modules.setdefault("mo.modules.communication.services.server_service", _comm_ss)

_SRC = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src"))
_SRC_PKG = os.path.join(_SRC, "web_browsing_activity")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)
if _SRC_PKG not in sys.path:
    sys.path.insert(0, _SRC_PKG)
